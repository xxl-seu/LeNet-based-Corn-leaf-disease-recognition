import os
import cv2
import sys
import numpy as np

print ("resize images in this folder:")
original_path0 = "original/0/"
original_path1 = "original/1/"
original_path2 = "original/2/"
original_path3 = "original/3/"
resize_path0 = "resize/0/"
resize_path1 = "resize/1/"
resize_path2 = "resize/2/"
resize_path3 = "resize/3/"

#分别将original下的四个文件夹中的图片压缩为32*32的图片，并存入resize文件夹下
for filename0 in os.listdir(original_path0):
    if os.path.splitext(filename0)[1] == '.jpg':
        img = cv2.imread(original_path0 + filename0)
        newImg = cv2.resize(img, dsize=(32, 32))
        cv2.imwrite(resize_path0 + filename0, newImg)
print("0 file finished")

for filename1 in os.listdir(original_path1):
    if os.path.splitext(filename1)[1] == '.jpg':
        img = cv2.imread(original_path1 + filename1)
        newImg = cv2.resize(img, dsize=(32, 32))
        cv2.imwrite(resize_path1 + filename1, newImg)
print("1 file finished")

for filename2 in os.listdir(original_path2):
    if os.path.splitext(filename2)[1] == '.jpg':
        img = cv2.imread(original_path2 + filename2)
        newImg = cv2.resize(img, dsize=(32, 32))
        cv2.imwrite(resize_path2 + filename2, newImg)
print("2 file finished")

for filename3 in os.listdir(original_path3):
    if os.path.splitext(filename3)[1] == '.jpg':
        img = cv2.imread(original_path3 + filename3)
        newImg = cv2.resize(img, dsize=(32, 32))
        cv2.imwrite(resize_path3 + filename3, newImg)
print("3 file finished")

